# Compilador-COOL
COOL � um projeto de compilador baseado na classe Stanford CS143 de compiladores do Professor Alex Aiken.

Esta � uma solu��o completa para o projeto COOL escrito em JAVA.





